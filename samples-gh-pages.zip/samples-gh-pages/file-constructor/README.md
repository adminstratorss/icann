File Constructor Sample
===
See https://googlechrome.github.io/samples/file-constructor/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5731244088229888