Lexical Declarations (ES6) Sample
===
See https://googlechrome.github.io/samples/lexical-declarations-es6/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/4645595339816960