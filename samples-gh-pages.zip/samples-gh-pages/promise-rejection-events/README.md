Promise Rejection Events Sample
===
See https://googlechrome.github.io/samples/promise-rejection-events/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/4805872211460096
