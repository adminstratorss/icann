new.target Sample
===
See https://googlechrome.github.io/samples/new-target-es6/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5210159227863040
