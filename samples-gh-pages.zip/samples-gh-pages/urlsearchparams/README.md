URLSearchParams Sample
===

See https://googlechrome.github.io/samples/urlsearchparams/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5632984866619392
