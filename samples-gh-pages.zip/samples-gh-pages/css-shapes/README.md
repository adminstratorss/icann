CSS Shapes Level 1 Sample
===
See https://googlechrome.github.io/samples/css-shapes for a live demo.

Learn more at https://www.chromestatus.com/feature/5163890719588352