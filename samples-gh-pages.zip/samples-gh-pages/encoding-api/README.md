Encoding API Sample
===
See https://googlechrome.github.io/samples/encoding-api/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5714368087982080