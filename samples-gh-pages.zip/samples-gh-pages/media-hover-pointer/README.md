'any-pointer' and 'any-hover' Media Queries Sample
===

See https://googlechrome.github.io/samples/media-hover-pointer/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6460705494532096
