addEventListener/removeEventListener non-optional arguments Sample
==================================================================
See https://googlechrome.github.io/samples/event-listeners-mandatory-arguments/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5640816202612736
