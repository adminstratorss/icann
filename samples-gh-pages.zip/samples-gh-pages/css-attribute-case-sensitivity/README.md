Case-insensitive Attribute Selector Matching
============================================
See https://googlechrome.github.io/samples/css-attribute-case-sensitivity/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5610936115134464
