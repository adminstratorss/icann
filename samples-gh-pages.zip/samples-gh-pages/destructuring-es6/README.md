Destructuring (ES2015) Sample
==================================
See https://googlechrome.github.io/samples/destructuring-es6/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/4588790303686656
