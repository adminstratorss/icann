Array Methods (ECMAScript 2015) Sample
======================================
See https://googlechrome.github.io/samples/array-methods-es6/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6732923508097024
