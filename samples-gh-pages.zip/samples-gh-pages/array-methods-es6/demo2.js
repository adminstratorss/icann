var divs = document.querySelectorAll('div');
Array.from(divs).forEach(function(node) {
  console.log(node);
});
