Touch-action pinch-zoom CSS property Sample
===
See https://googlechrome.github.io/samples/touch-action/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5670200775016448
