Service Worker Sample: WindowClient.navigate()
===
See https://googlechrome.github.io/samples/service-worker/windowclient-navigate/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5314750808326144
