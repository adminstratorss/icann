Service Worker Sample: Mock Responses
===
See https://googlechrome.github.io/samples/service-worker/mock-responses/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6561526227927040
