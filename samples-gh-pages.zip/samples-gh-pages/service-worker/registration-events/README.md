Service Worker Sample: Detailed Registration
===
See https://googlechrome.github.io/samples/service-worker/registration-events/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6561526227927040
