Service Worker Video Cache Sample
===
See https://googlechrome.github.io/samples/service-worker/prefetch-video/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6561526227927040
