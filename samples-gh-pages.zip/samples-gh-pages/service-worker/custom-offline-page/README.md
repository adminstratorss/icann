Service Worker Sample: Custom Offline Page
===
See https://googlechrome.github.io/samples/service-worker/custom-offline-page/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6561526227927040
