Service Worker Sample: Using window.caches
===
See https://googlechrome.github.io/samples/service-worker/window-caches/index.html for a live demo.

Learn more at https://www.chromestatus.com/features/5072127703121920
