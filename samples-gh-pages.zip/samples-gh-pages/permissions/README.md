Permissions API sample
===
See https://googlechrome.github.io/samples/permissions/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6376494003650560
