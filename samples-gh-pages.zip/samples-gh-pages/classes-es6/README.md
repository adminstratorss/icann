Classes (ES6) Sample
===
See https://googlechrome.github.io/samples/classes-es6/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/4633745457938432