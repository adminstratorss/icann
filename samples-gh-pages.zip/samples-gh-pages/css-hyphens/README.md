CSS Hyphens Property Sample
===
See https://googlechrome.github.io/samples/css-hyphens/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5642121184804864
