Screen Orientation Sample
===
See https://googlechrome.github.io/samples/screen-orientation/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6191285283061760
