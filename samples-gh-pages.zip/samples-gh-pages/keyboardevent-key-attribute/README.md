KeyboardEvent key Attribute Sample
===
See https://googlechrome.github.io/samples/keyboardevent-key-attribute/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/4748790720364544
