
Template Literals (ES6) Sample
===

See https://googlechrome.github.io/samples/template-literals-es6/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/4743002513735680


