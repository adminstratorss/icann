window.GoogleSamples = window.GoogleSamples || {};
window.GoogleSamples.Config = window.GoogleSamples.Config || {
  gcmAPIKey: '<Your Cloud Messaging API Key from https://console.firebase.google.com>'
};
