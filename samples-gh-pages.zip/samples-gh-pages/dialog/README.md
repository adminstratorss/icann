<dialog> Element Sample
===
See https://googlechrome.github.io/samples/dialog/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5770237022568448