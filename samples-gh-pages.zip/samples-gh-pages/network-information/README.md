Network Information API Sample
===
See https://googlechrome.github.io/samples/network-information/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6338383617982464
