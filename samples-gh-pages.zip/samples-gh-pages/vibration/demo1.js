function example1() {
  // Vibrate for 500ms
  navigator.vibrate([500]);
}
