function stopVibrations() {
  // You can also stop an ongoing vibration pattern by specifying a vibration
  // length of zero.
  navigator.vibrate(0);
}
