function example2() {
  // For a single value you can pass in a Number rather than an Array
  navigator.vibrate(500);
}
