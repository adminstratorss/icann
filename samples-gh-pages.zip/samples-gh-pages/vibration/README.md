Vibration API Sample
===

See https://googlechrome.github.io/samples/vibration/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5698768766763008
