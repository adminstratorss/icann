Web Application Manifest Sample
===
See https://googlechrome.github.io/samples/web-application-manifest/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/6488656873259008
