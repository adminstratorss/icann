Alpha Channel Support in CSS Color Parsing Sample
===
See https://googlechrome.github.io/samples/css-alpha-channel/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5685348285808640
