Rasterization & will-change: transform Sample
=============================================
See https://googlechrome.github.io/samples/css-will-change-transform-rasterization/index.html for a live demo.

Learn more at https://www.chromestatus.com/feature/5637351992721408
